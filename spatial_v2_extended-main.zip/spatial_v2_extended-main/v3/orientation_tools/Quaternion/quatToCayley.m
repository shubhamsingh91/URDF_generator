function c = quatToCayley(q)
c = q(2:4)/q(1);
end

