function m = cayleyToMRP(c)
m = c/(1+sqrt(1+c'*c));
end

