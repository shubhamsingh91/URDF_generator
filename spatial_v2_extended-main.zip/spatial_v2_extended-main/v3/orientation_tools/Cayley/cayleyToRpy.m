function rpy = cayleyToRpy(c)

rpy = rotToRpy( cayleyToRot(c) );

end

