function angle_axis = cayleyToAngleAxis(c)

angle_axis = rotToAngleAxis( cayleyToRot(c) );

end

