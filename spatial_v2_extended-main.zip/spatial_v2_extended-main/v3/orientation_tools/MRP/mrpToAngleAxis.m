function angle_axis = mrpToAngleAxis(c)

angle_axis = rotToAngleAxis( mrpToRot(c) );

end

