function rpy = mrpToRpy(m)

rpy = rotToRpy( mrpToRot(m) );

end

