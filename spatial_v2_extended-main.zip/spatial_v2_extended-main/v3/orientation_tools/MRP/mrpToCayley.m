function c = mrpToCayley(m)
c = 2*m/(1-m'*m);
end

