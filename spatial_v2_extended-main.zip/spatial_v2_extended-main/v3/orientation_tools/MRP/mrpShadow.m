function ms = mrpShadow(m)

ms = -m/(m'*m);

end

