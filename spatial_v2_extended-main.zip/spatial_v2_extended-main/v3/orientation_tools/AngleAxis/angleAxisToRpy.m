function rpy = angleAxisToRpy(angle_axis)

rpy = rotToRpy(angleAxisToRot(angle_axis));

end

