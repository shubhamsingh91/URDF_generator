function aa = rotToExpCoords(R)
aa = skew(logm(R));
end

