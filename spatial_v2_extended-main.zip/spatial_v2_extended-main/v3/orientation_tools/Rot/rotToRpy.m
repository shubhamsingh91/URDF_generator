function [rpy1 rpy2] = rotToRpy(R)

[rpy1 rpy2] = rotToFixedAngles(R,[1 2 3]);

end

